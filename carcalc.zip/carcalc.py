import os

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    while True: clear_screen()

type_pow = input("chose (HP/WHP)").upper()
power = float(input("Enter your power: "))
type_drive = input("Enter your type drive (FWD/AWD/RWD): ").strip().upper()


#HP TO WHP
if type_pow == "HP" and type_drive == "FWD":
    FWD = power * 0.89
    print(f"your power is {FWD} whp")
elif type_pow == "HP" and type_drive == "AWD":
    AWD = power * 0.75
    print(f"your power is {AWD} whp")
elif type_pow == "HP" and type_drive == "RWD":
    RWD = power * 0.84
    print(f"your power is {RWD} whp")
#WHP TO HP
elif type_pow == "WHP" and type_drive == "FWD":
    FWD = power / 0.89
    print(f"your power is {round(FWD,2)} hp")
elif type_pow == "WHP" and type_drive == "AWD":
    AWD = power / 0.75
    print(f"your power is {AWD} hp")
elif type_pow == "WHP" and type_drive == "RWD":
    RWD = power / 0.84
    print(f"your power is {RWD} hp")
else:
    print(f"{type_drive}  or {type_pow} his not supported")




