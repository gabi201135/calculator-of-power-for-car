
import os



power = None

# developer text

text = "====POWERED BY PG===="
version = "Version: 0.2 Beta"


# noinspection deprecation
def clear_screen():

       os.system("cls" if os.name == "nt" else "clear")

while True:

        print(f"{text}")
        print(f"{version}")

        type_power = input("chose (HP/WHP)").upper()
        power = float(input("Enter your power: "))
        type_wdrive = input("Enter your type drive (FWD/AWD/RWD): ").strip().upper()


#WHP TO HP
        if type_power == "WHP" and type_wdrive == "FWD":
          FWD = power / 0.89
          print(f"your power is {FWD} hp")
        elif type_power == "WHP" and type_wdrive == "RWD":
            RWD = power / 0.84
            print(f"your power is {RWD} hp")
        elif type_power == "WHP" and type_wdrive == "AWD":
            AWD = power / 0.75
            print(f"your power is {AWD} hp")
#HP TO WHP
        elif type_power == "HP" and type_wdrive == "FWD":
            FWD = power * 0.89
            print(f"your power is {FWD} whp")
        elif type_power == "HP" and type_wdrive == "AWD":
            AWD = power * 0.75
            print(f"your power is {AWD} whp")
        elif type_power == "HP" and type_wdrive == "RWD":
            RWD = power * 0.84
            print(f"your power is {RWD} whp")

        else:
            print("Please enter a correct value")
        choise = input("\nwould you like to continue? (y/n): ").strip().upper()
        if choise == "N":
            print("bye")



            clear_screen()
        else:

            print("thank you")